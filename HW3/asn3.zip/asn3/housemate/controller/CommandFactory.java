package cscie97.asn3.housemate.controller;


/**
 * The CommandFactory is responsible for creating each component of our command to be executed
 * 
 *
 */


public class CommandFactory {


	
	/**
	 * This method decyphers commands that are to be executed based on 
	 * the tokenized stimuli
	 *
	 */
	public void createCommand() {


	}






}
